package com.knk.home_alone.domain;

import lombok.Data;

@Data
public class MainVO {
	private String userName;
	private String userID;
	private String userPW;
	private String identidication1;
	private String identidication2;
	private String email;
	private String emailAddr;
	private String emailOpt;
	private String firstNum1;
	private String userPhone1;
	private String userPhone2;
	private String firstNum2;
	private String userPhone3;
	private String userPhone4;
	private String zipNo;
	private String roadAddrPart1;
	private String addrDetail;

}
