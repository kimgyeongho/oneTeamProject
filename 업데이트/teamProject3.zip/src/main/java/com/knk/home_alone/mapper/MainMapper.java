package com.knk.home_alone.mapper;


import com.knk.home_alone.domain.MainVO;



public interface MainMapper {
	 
	//회원가입   
	public void oneteam_join(MainVO VO)throws Exception;
	
	//로그인
	public MainVO oneteam_login(MainVO VO)throws Exception ;
	
	//회원정보 수정
	public void oneteam_Update(MainVO VO)throws Exception;

}
